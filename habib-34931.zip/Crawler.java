/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crawler;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class Crawler {
    
public static HashMap<String, ArrayList<String>> dirFiles = new HashMap<String, ArrayList<String>>(); 

    public static void listFilesForFolder(File folder)
            throws IOException {

        if(folder.isDirectory()) {

            ArrayList<String> fileNames = new ArrayList<String>();

            for (final File fileEntry : folder.listFiles()) {
               // System.out.println(fileEntry.toString());
                if (fileEntry.isDirectory()) {
                //  System.out.println(fileEntry.toString());
                    listFilesForFolder(fileEntry);
                } else {
                    String fileName = (fileEntry.getPath()).toString();
                    fileNames.add(fileEntry.getPath());
                }
            }
            dirFiles.put(folder.getName(), fileNames);
        }
    }

    public static void main(String[] args) throws IOException {
        // TODO Auto-generated method stub
        String query=null;
        
        int i=0;
        listFilesForFolder(new File("E:/Study"));
        for(Entry <String, ArrayList<String>> foldername : dirFiles.entrySet())
        {
            System.out.println(foldername.getKey() + " " + foldername.getValue());
        }
        
        System.out.println("Enter search keyWord");
        //Scanner input=new Scanner(System.in);
        //query=input.nextLine();
        for(Entry<String, ArrayList<String>> foldername : dirFiles.entrySet())
        {
            String[] path=new String[foldername.getValue().size()];
            
            System.out.println(path);

            path = foldername.getValue().toArray(path);

            for(String s : path)
            {
                s.split("/");
            }
			
        }
        
        //System.out.println("Found Content:\n");
        
    }
    
}
